########################################################################################################
# The RWKV Language Model - https://github.com/BlinkDL/RWKV-LM
########################################################################################################

import json, os, re, copy
import numpy as np
import torch
from torch.utils.data import Dataset
from pytorch_lightning.utilities import rank_zero_info
from typing import Dict, List, Sequence, Any
from .utils import gpt4v_crop, largest_3n_plus_2_prime



class MyDataset(Dataset):
    def __init__(self, args):
        self.args = args
        self.seq_len = args.seq_len
        self.samples_per_epoch = self.args.epoch_steps * self.args.real_bsz

    def __len__(self):
        return self.args.epoch_steps * self.args.micro_bsz

    def __getitem__(self, idx):
        # sample a random inputs and targets
        data_dict = {}
        data_dict["input_points"] = torch.randn(self.seq_len, 1, dtype=torch.float32)
        data_dict["labels"] = torch.randn(self.seq_len, 1, dtype=torch.float32)
        return data_dict